-- =============================================
-- Author:	吕东来	
-- Create date: 2014-5-6
-- Description:	1.插入Basic_Queue_Stat表,清空Basic_Queue_Work表  2.初始化Basic_WorkStation_Work  3.清空cmd表  4.插入初始化cmd
-- =============================================
CREATE PROCEDURE [dbo].[SP_Process_CurrDate_Queue]
AS 
    INSERT  INTO dbo.Basic_Queue_Stat
            SELECT  Site_ID ,
                    RegDate ,
                    Track_No ,
                    Queue_No ,
                    SrvGroup_ID ,
                    SrvCode_ID ,
                    Appoint_Time ,
                    Enter_Time ,
                    Start_Time ,
                    Next_Time ,
                    Confirm_Time ,
                    End_Time ,
                    Call_Times ,
                    Stamp_Time ,
                    WS_ID ,
                    Staff_ID ,
                    Staff_Code ,
                    Customer_ID ,
                    Customer_No ,
                    Customer_Name ,
                    Customer_Type ,
                    Srv_PJ ,
                    Pre_Date_ID ,
                    Note_Text
            FROM    dbo.Basic_Queue_Work
            
    --初始化Basic_WorkStation_Work 
    TRUNCATE TABLE dbo.Basic_Queue_Work
    
    --清空cmd表
    TRUNCATE TABLE dbo.Basic_ControlCmd
    
    --初始化Basic_WorkStation_Work
    UPDATE  dbo.Basic_WorkStation_Work
    SET     SrvGroup_ID = 0 ,
            WS_Status_Type = 1
    
    --工作站
    INSERT  INTO dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    2 ,-- Cmd_Group_ID - smallint
                    4 ,-- Cmd_Type_ID - smallint
                    N'' , -- Cmd_Info - nvarchar(50)
                    A.WS_ID ,-- Cmd_Para_1 - nvarchar(50)
                    CONVERT(NVARCHAR(30), WS_Display_ID) + '|'
                    + CONVERT(NVARCHAR(30), WS_Display_Type) + '|'
                    + ISNULL(CONVERT(NVARCHAR(100), B.WS_Scroll_Txt), '') ,-- Cmd_Para_2 - nvarchar(50)
                    CONVERT(NVARCHAR(30), A.WS_Name) + '|'
                    + CONVERT(NVARCHAR(30), A.WS_No) + '|'
                    + ISNULL(CONVERT(NVARCHAR(30), B.WS_Display_Name), '') ,  -- Cmd_Para_3 - nvarchar(50)
                    N'' ,-- Cmd_Para_4 - nvarchar(50)
                    0 -- Cmd_Status - smallint
            FROM    dbo.Basic_WorkStation A
                    LEFT JOIN dbo.Basic_WorkStation_Work B ON A.WS_ID = b.WS_ID
            
           
    --主显示设备
    SELECT  MD_WS_ID ,
            MD_ID ,
            MD_Type ,
            MD_Display_Mode
    INTO    #t1
    FROM    dbo.Basic_MainDisplay
    
    WHILE ( EXISTS ( SELECT TOP 1
                            md_id
                     FROM   #t1 ) ) 
        BEGIN 
            --定义主显示设备ID
            DECLARE @MD_ID INT 
            DECLARE @MD_Type INT
            DECLARE @MD_Display_Mode INT 
            
            --获取主显示设备ID
            SELECT  @MD_ID = MD_ID ,
                    @MD_Type = MD_Type ,
                    @MD_Display_Mode = MD_Display_Mode
            FROM    #t1
         
            --插入cmd
            INSERT  INTO dbo.Basic_ControlCmd
                    ( ControlCmd_Time ,
                      Cmd_Group_ID ,
                      Cmd_Type_ID ,
                      Cmd_Info ,
                      Cmd_Para_1 ,
                      Cmd_Para_2 ,
                      Cmd_Para_3 ,
                      Cmd_Para_4 ,
                      Cmd_Status
                    )
                    SELECT  GETDATE() ,-- ControlCmd_Time - datetime 
                            1 ,-- Cmd_Group_ID - smallint
                            4 ,-- Cmd_Type_ID - smallint
                            N'' , -- Cmd_Info - nvarchar(100)
                            CONVERT(NVARCHAR(30), @MD_ID) , -- Cmd_Para_1 - nvarchar(100)
                            CONVERT(NVARCHAR(10), @MD_Type) + '|'
                            + CONVERT(NVARCHAR(10), @MD_Display_Mode) , -- Cmd_Para_2 - nvarchar(100)
                            '0|0|0|0' , -- Cmd_Para_3 - nvarchar(100)
                            B.WS_Name + '|' + B.WS_No + '|' + D.Staff_Name
                            + '|' + CONVERT(NVARCHAR(10), B.WS_ID) , -- Cmd_Para_4 - nvarchar(100)
                            0 -- Cmd_Status - smallint
                    FROM    dbo.SplitStr(( SELECT   MD_WS_ID
                                           FROM     #t1
                                           WHERE    MD_ID = @MD_ID
                                         ), ',') A
                            INNER JOIN dbo.Basic_WorkStation B ON CONVERT(VARCHAR(30), B.WS_ID) = A.F1
                            INNER JOIN dbo.Basic_WorkStation_Work C ON B.WS_ID = C.WS_ID
                            INNER JOIN dbo.Basic_StaffInfo D ON C.Staff_ID = D.Staff_ID
                    
      
            DELETE  FROM #t1
            WHERE   MD_ID = @MD_ID       
        END
        
    DROP TABLE #t1

go

