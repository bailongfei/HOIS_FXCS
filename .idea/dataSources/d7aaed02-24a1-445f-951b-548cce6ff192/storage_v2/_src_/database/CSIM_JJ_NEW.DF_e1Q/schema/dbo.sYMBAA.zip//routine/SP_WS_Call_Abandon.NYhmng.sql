-- =============================================
-- Author:		吕东来
-- Create date: <Create Date,,>
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Call_Abandon] @DataID INT
AS 
    UPDATE  dbo.Basic_Queue_Work
    SET     Status_Type = 31 ,
            Stamp_Time = GETDATE() ,
            Confirm_Time = GETDATE() ,
            Queue_Pos = -1
    WHERE   Data_ID = @DataID

go

