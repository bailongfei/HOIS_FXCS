--服务类别关系视图
CREATE VIEW [dbo].[View_SrvGroup]
AS
    SELECT  SRVGROUP_ID ,
            SRVGROUP_NAME ,
            SRVGROUP_CODE ,
            SRVGROUP_LETTER
    FROM    dbo.BASIC_SRVGROUP

go

