-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	工作站关闭 插入cmd
-- =============================================
CREATE PROCEDURE [dbo].[SP_Cmd_WS_Close]
    @WS_ID INT ,
    @WS_Display_ID INT ,
    @WS_Display_Type INT ,
    @WS_Scroll_Txt NVARCHAR(100) ,
    @WS_Name NVARCHAR(100) ,
    @WS_No NVARCHAR(30) ,
    @WS_Display_Name NVARCHAR(20) ,
    @Staff_Name NVARCHAR(50)
AS 


    --INSERT  dbo.Basic_ControlCmd
    --        ( ControlCmd_Time ,
    --          Cmd_Group_ID ,
    --          Cmd_Type_ID ,
    --          Cmd_Info ,
    --          Cmd_Para_1 ,
    --          Cmd_Para_2 ,
    --          Cmd_Para_3 ,
    --          Cmd_Para_4 ,
    --          Cmd_Status
    --        )
    --VALUES  ( GETDATE() , -- ControlCmd_Time - datetime
    --          2 , -- Cmd_Group_ID - smallint
    --          4 , -- Cmd_Type_ID - smallint
    --          N'' , -- Cmd_Info - nvarchar(50)
    --          CONVERT(VARCHAR(30), @WS_ID) , -- Cmd_Para_1 - nvarchar(50)
    --          CONVERT(VARCHAR(30), @WS_Display_ID) + '|'
    --          + CONVERT(VARCHAR(30), @WS_Display_Type) + '|'
    --          + ( SELECT    ISNULL(@WS_Scroll_Txt, '')
    --            ) , -- Cmd_Para_2 - nvarchar(50)
    --          @WS_Name + '|' + CONVERT(VARCHAR(30), @WS_No) + '|'
    --          + ( SELECT    ISNULL(@WS_Display_Name, '')
    --            ) , -- Cmd_Para_3 - nvarchar(50)
    --          N'' , -- Cmd_Para_4 - nvarchar(50)
    --          0  -- Cmd_Status - smallint
    --        )
 --大屏,插入cmd表,       
    INSERT  dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    1 ,
                    4 ,
                    '' ,
                    MD_ID , -- Cmd_Para_1 - nvarchar(50)
                    CONVERT(NVARCHAR(10), MD_Type) + '|'
                    + CONVERT(NVARCHAR(10), MD_Display_Mode) , -- Cmd_Para_2 - nvarchar(50)
                    '0|0|0|0|0' , -- Cmd_Para_3 - nvarchar(50)
                    @WS_Name + '|' + @WS_No + '|' + @Staff_Name + '|'
                    + CONVERT(NVARCHAR(10), @WS_ID) , -- Cmd_Para_4 - nvarchar(50)
                    0  -- Cmd_Status - smallint
            FROM    dbo.Basic_MainDisplay
            WHERE   MD_WS_ID LIKE '%,' + CONVERT(VARCHAR(30), @WS_ID) + ',%'

go

