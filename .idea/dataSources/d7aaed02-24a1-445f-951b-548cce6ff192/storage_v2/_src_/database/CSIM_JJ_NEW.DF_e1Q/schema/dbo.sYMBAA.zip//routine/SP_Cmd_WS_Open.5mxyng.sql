-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	工作站打开 插入cmd
-- =============================================
CREATE PROCEDURE [dbo].[SP_Cmd_WS_Open]
    @WS_ID INT ,
    @WS_Display_ID INT ,
    @WS_Display_Type INT ,
    @WS_Scroll_Txt NVARCHAR(100) ,
    @WS_No NVARCHAR(30) ,
    @WS_Name VARCHAR(30) ,
    @WS_Display_Name VARCHAR(30) ,
    @Staff_Code VARCHAR(30) ,
    @Staff_Name VARCHAR(30) ,
    @Staff_Level INT ,
    @Staff_Title VARCHAR(30) ,
    @Staff_Pic NVARCHAR(200)
AS --工作站,插入cmd表,
    INSERT  INTO dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    2 ,
                    3 ,
                    '' ,
                    @WS_ID , -- Cmd_Para_1 - nvarchar(50)
                    CONVERT(VARCHAR(30), @WS_Display_ID) + '|'
                    + CONVERT(VARCHAR(30), @WS_Display_Type) + '|'
                    + ( SELECT  ISNULL(@WS_Scroll_Txt, '')
                      ) , -- Cmd_Para_2 - nvarchar(50)
                    @WS_Name + '|' + CONVERT(VARCHAR(30), @WS_No) + '|'
                    + @WS_Display_Name , -- Cmd_Para_3 - nvarchar(50)
                    @Staff_Code + '|' + @Staff_Name + '|'
                    + CONVERT(VARCHAR(30), @Staff_Level) + '|' + @Staff_Title
                    + '|' + @Staff_Pic , -- Cmd_Para_4 - nvarchar(50)
                    0  -- Cmd_Status - smallint
            FROM    dbo.Basic_MainDisplay
            WHERE   MD_WS_ID LIKE '%,' + CONVERT(VARCHAR(30), @WS_ID) + ',%'
            
    --大屏,插入cmd表,       
    INSERT  dbo.Basic_ControlCmd
            ( ControlCmd_Time ,
              Cmd_Group_ID ,
              Cmd_Type_ID ,
              Cmd_Info ,
              Cmd_Para_1 ,
              Cmd_Para_2 ,
              Cmd_Para_3 ,
              Cmd_Para_4 ,
              Cmd_Status
                    
            )
            SELECT  GETDATE() , -- ControlCmd_Time - datetime
                    1 ,
                    3 ,
                    '' ,
                    MD_ID , -- Cmd_Para_1 - nvarchar(50)
                    CONVERT(VARCHAR(30), @WS_Display_ID) + '|'
                    + CONVERT(VARCHAR(30), @WS_Display_Type) + '|'
                    + ( SELECT  ISNULL(@WS_Scroll_Txt, '')
                      ) , -- Cmd_Para_2 - nvarchar(50)
                    '0|0|0|0' , -- Cmd_Para_3 - nvarchar(50)
                    @WS_Name + '|' + @WS_No + '|' + @Staff_Name + '|'
                    + CONVERT(NVARCHAR(10), @WS_ID) , -- Cmd_Para_4 - nvarchar(50)
                    0  -- Cmd_Status - smallint
            FROM    dbo.Basic_MainDisplay
            WHERE   MD_WS_ID LIKE '%,' + CONVERT(VARCHAR(30), @WS_ID) + ',%'

go

