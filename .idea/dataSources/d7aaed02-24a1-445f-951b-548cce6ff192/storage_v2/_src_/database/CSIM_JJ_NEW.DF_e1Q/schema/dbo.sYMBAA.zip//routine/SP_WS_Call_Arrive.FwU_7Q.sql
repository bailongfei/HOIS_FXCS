-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-8
-- Description:	确认到达
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Call_Arrive] @WS_ID INT, @DataID INT
AS --自定义变量
 
    UPDATE  dbo.Basic_Queue_Work
    SET     Confirm_Time = GETDATE() ,
            Stamp_Time = GETDATE() ,
            Status_Type = 13
    WHERE   Data_ID = @DataID

go

