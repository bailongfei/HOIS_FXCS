-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-8
-- Description:	重呼
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Call_Repeat] @WS_ID INT, @DataID INT
AS --更新Basic_Queue_Work

    DECLARE @SrvGroup_ID INT 
    DECLARE @Customer_Name VARCHAR(30)
    DECLARE @Queue_No INT 
    DECLARE @Customer_Type INT 
    
    DECLARE @SrvGroup_Letter VARCHAR(30)
    ---
    DECLARE @SrvGroup_Name NVARCHAR(100) 
    DECLARE @WS_Name NVARCHAR(100) 
    DECLARE @WS_No NVARCHAR(10) 
    DECLARE @WS_Display_ID INT 
    DECLARE @WS_Display_Type INT
    DECLARE @Staff_ID INT
    DECLARE @Staff_Name NVARCHAR(50)
    DECLARE @WS_Display_Name NVARCHAR(20)
    
    
    SELECT  @WS_Name = WS_Name ,
            @WS_No = WS_No ,
            @WS_Display_ID = WS_Display_ID ,
            @WS_Display_Type = WS_Display_Type
    FROM    dbo.Basic_WorkStation
    WHERE   WS_ID = @WS_ID
    
    SELECT  @Staff_ID = Staff_ID ,
            @WS_Display_Name = WS_Display_Name
    FROM    dbo.Basic_WorkStation_Work
    WHERE   WS_ID = @WS_ID
    
    SELECT  @Staff_Name = Staff_Name
    FROM    dbo.Basic_StaffInfo
    WHERE   Staff_ID = @Staff_ID
    
    --获取客户信息
    SELECT  @SrvGroup_ID = SrvGroup_ID ,
            @Customer_Name = Customer_Name ,
            @Queue_No = Queue_No ,
            @Customer_Type = Customer_Type
    FROM    dbo.Basic_Queue_Work
    WHERE   Data_ID = @DataID
    
    SELECT  @SrvGroup_Name = SrvGroup_Name ,
            @SrvGroup_Letter = SrvGroup_Letter
    FROM    dbo.Basic_SrvGroup
    WHERE   SrvGroup_ID = @SrvGroup_ID

    --呼叫次数加1
    UPDATE  dbo.Basic_Queue_Work
    SET     Call_Times = Call_Times + 1 ,
            Stamp_Time = GETDATE()
    WHERE   Data_ID = @DataID

    --插入CMD 
    EXEC SP_Cmd_WS_Call_Repeat @SrvGroup_ID, @Customer_Name, @Customer_Type,
        @WS_ID, @SrvGroup_Letter, @Queue_No, @SrvGroup_Name, @WS_Name, @WS_No,
        @Staff_Name, @WS_Display_ID, @WS_Display_Type, @WS_Display_Name
                
    --成功
    SELECT  1

go

