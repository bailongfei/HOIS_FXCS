-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	弃号
-- =============================================
CREATE PROCEDURE [dbo].[SP_MS_DeleteQueue] @DataID INT
AS 
    UPDATE  dbo.Basic_Queue_Work
    SET     Status_Type = 32 ,
            Stamp_Time = GETDATE()
    WHERE   Data_ID = @DataID

go

