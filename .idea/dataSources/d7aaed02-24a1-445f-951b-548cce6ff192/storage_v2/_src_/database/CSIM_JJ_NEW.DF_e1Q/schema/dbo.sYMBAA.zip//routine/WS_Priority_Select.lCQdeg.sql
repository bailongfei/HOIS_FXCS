-- =============================================
-- Author:		吕东来
-- Create date: 2014-4-11
-- Description:	更新优先级
-- =============================================
CREATE PROCEDURE [dbo].[WS_Priority_Select]
    @WS_ID INT ,
    @Priority_ID INT
AS 
    UPDATE  dbo.Basic_WorkStation_Work
    SET     WS_Preiod_Work = @Priority_ID
    WHERE   WS_ID = @WS_ID

go

