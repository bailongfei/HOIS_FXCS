-- =============================================
-- Author:		吕东来
-- Create date: 2014-6-11
-- Description:	取票号
-- =============================================
CREATE PROCEDURE [dbo].[SP_Ticket_Dis]
    @Site_ID INT ,
    @SrvGroup_ID INT ,
    @SrvCode_ID INT ,
    @Appoint_Time DATETIME ,
    @Customer_ID NVARCHAR(30) ,
    @Customer_No NVARCHAR(30) ,
    @Customer_Name NVARCHAR(50) ,
    @Customer_Type INT
AS --排队计数

    DECLARE @MAXQueueNo INT 
    DECLARE @Track_No INT 
    DECLARE @CountWait INT 
    DECLARE @MaxQueue_Pos INT 
    DECLARE @Status_Type INT 
    
    
   --***************************************自动清空
 if(  ( select COUNT(*) from dbo.Basic_Queue_Work where  
    CONVERT(date,RegDate)=CONVERT(date,getdate()))=0)
    begin
        exec dbo.SP_Process_CurrDate_Queue
    end
    --***************************************
    
    SELECT  @MAXQueueNo = MAX(Queue_No)
    FROM    dbo.Basic_Queue_Work
    WHERE   SrvGroup_ID = @SrvGroup_ID
    
    --根据服务类别  查询起始号码        
    IF @MAXQueueNo IS NULL 
        BEGIN
            SELECT  @MAXQueueNo = SrvGroup_Start_Num
            FROM    dbo.Basic_SrvGroup
            WHERE   SrvGroup_ID = @SrvGroup_ID
        END 
    
    SELECT  @Track_No = COUNT(*)
    FROM    dbo.Basic_Queue_Work
    
    SELECT  @CountWait = COUNT(*)
    FROM    dbo.Basic_Queue_Work
    WHERE   SrvGroup_ID = @SrvGroup_ID
            AND Status_Type BETWEEN 3 AND 13
       
    SELECT  @MaxQueue_Pos = MAX(Queue_Pos)
    FROM    dbo.Basic_Queue_Work
    WHERE   SrvGroup_ID = @SrvGroup_ID
       
    --返回排队数--返回等候数
    SELECT  @MAXQueueNo + 1 ,
            @CountWait ,
            ( SELECT    SrvGroup_Letter
              FROM      dbo.Basic_SrvGroup
              WHERE     SrvGroup_ID = @SrvGroup_ID
            )
            
    --返回票号信息
    SELECT  *
    FROM    dbo.Basic_Ticket
    WHERE   Ticket_ID = ( SELECT    SrvGroup_Ticket_ID
                          FROM      dbo.Basic_SrvGroup
                          WHERE     SrvGroup_ID = @SrvGroup_ID
                        )
       
    --插入排队数据     
    INSERT  dbo.Basic_Queue_Work
            ( Site_ID ,
              RegDate ,
              Track_No ,--自增
              Queue_No ,
              Queue_Pos ,
              SrvGroup_ID ,
              SrvCode_ID ,
              Appoint_Time ,
              Enter_Time ,
              Start_Time ,
              --Next_Time ,
              --Confirm_Time ,
              --End_Time ,
              Call_Times ,
              Stamp_Time ,
              WS_ID ,
              Staff_ID ,
              Staff_Code ,
              Customer_ID ,
              Customer_No ,
              Customer_Name ,
              Customer_Type ,
              Status_Type ,
              Srv_PJ ,
              Pre_SrvGroup_ID ,
              Pre_SrvCode_ID ,
              Pre_WS_ID ,
              Pre_Staff_ID ,
              Pre_Staff_Code ,
              Pre_Date_ID ,
              Note_Text
            )
    VALUES  ( @Site_ID , -- Site_ID - smallint
              GETDATE() , -- RegDate - datetime
              @Track_No + 1 , --Track_No -- bigint
              ISNULL(@MAXQueueNo + 1, 1) , -- Queue_No - int
              ISNULL(@MaxQueue_Pos + 1, 1) , -- Queue_Pos - int
              @SrvGroup_ID , -- SrvGroup_ID - int
              @SrvCode_ID , -- SrvCode_ID - int
              @Appoint_Time ,--Appoint_Time - datetime
              NULL , -- Enter_Time - datetime
              GETDATE() , -- Start_Time - datetime
             -- Next_Time - datetime
             -- Confirm_Time - datetime
             -- End_Time - datetime
              0 , -- Call_Times - smallint
              GETDATE() , -- Stamp_Time - datetime
              0 , -- WS_ID - smallint
              0 , -- Staff_ID - int
              N'' , -- Staff_Code - nvarchar(20)
              @Customer_ID , -- Customer_ID - nvarchar(30)
              @Customer_No , -- Customer_No - nvarchar(30)
              @Customer_Name , -- Customer_Name - nvarchar(50)
              @Customer_Type , -- Customer_Type - smallint
              3 , -- Status_Type - smallint
              0 , -- Srv_PJ - smallint
              0 , -- Pre_SrvGroup_ID - int
              0 , -- Pre_SrvCode_ID - int
              0 , -- Pre_WS_ID - smallint
              0 , -- Pre_Staff_ID - int
              N'' , -- Pre_Staff_Code - nvarchar(20)
              0 , -- Pre_Date_ID - int
              ''  -- Note_Text - varchar(200)
            )

go

