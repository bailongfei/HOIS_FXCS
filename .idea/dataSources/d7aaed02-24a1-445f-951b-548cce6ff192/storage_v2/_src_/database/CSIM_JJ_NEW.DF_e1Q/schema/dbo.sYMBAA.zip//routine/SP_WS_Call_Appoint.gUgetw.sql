-- =============================================
-- Author:		吕东来
-- Create date: <Create Date,,>
-- Description:	指定呼叫
-- =============================================
CREATE PROCEDURE [dbo].[SP_WS_Call_Appoint]
    @WS_ID INT ,
    @Pre_DataID INT ,--前一位客户
    @DataID INT--选中的客户
AS 
    DECLARE @Staff_Code INT
    DECLARE @Staff_ID INT 
    DECLARE @Staff_Name VARCHAR(30)
    
    DECLARE @SrvGroup_ID INT 
    DECLARE @SrvCode_ID INT 
    DECLARE @SrvGroup_Name NVARCHAR(100) 
    DECLARE @SrvGroup_Letter VARCHAR(30)
    
    DECLARE @Track_No INT 
    DECLARE @Queue_No INT 
    DECLARE @Customer_ID NVARCHAR(30)
    DECLARE @Customer_Name NVARCHAR(30)
    DECLARE @Customer_Type INT
    DECLARE @Next_Queue_No INT 
    DECLARE @Next_Customer_Name NVARCHAR(30)
    
    DECLARE @WS_No NVARCHAR(30) 
    DECLARE @WS_Name VARCHAR(30)
    DECLARE @WS_Display_ID INT 
    DECLARE @WS_Display_Type INT 
    DECLARE @WS_Display_Name NVARCHAR(20)
    DECLARE @Priority_ID INT 
   
    --获取员工信息
    SELECT  @Staff_Code = Staff_Code ,
            @Staff_ID = Staff_ID ,
            @WS_No = B.WS_No ,
            @WS_Name = WS_Name ,
            @WS_Display_ID = WS_Display_ID ,
            @WS_Display_Type = WS_Display_Type ,
            @Priority_ID = A.WS_Preiod_Work ,
            @WS_Display_Name = WS_Display_Name
    FROM    dbo.Basic_WorkStation_Work A
            INNER JOIN dbo.Basic_WorkStation B ON A.WS_ID = B.WS_ID
    WHERE   A.WS_ID = @WS_ID

    --获取下一位客户 SrvGroup_ID/SrvCode_ID
    SELECT  @SrvGroup_ID = SrvGroup_ID ,
            @SrvCode_ID = SrvCode_ID ,
            @Track_No = Track_No ,
            @Queue_No = Queue_No ,
            @Customer_ID = Customer_ID ,
            @Customer_Name = Customer_Name ,
            @Customer_Type = Customer_Type
    FROM    dbo.Basic_Queue_Work
    WHERE   Data_ID = @DataID
    
    SELECT  @Staff_Name = Staff_Name
    FROM    dbo.Basic_StaffInfo
    WHERE   Staff_ID = @Staff_ID
    
    SELECT  @SrvGroup_Name = SrvGroup_Name ,
            @SrvGroup_Letter = SrvGroup_Letter
    FROM    dbo.Basic_SrvGroup
    WHERE   SrvGroup_ID = @SrvGroup_ID
    
    --更新前一条数据
    UPDATE  dbo.Basic_Queue_Work
    SET     Stamp_Time = GETDATE() ,
            End_Time = GETDATE() ,
            WS_ID = @WS_ID ,
            Staff_Code = @Staff_Code ,
            Staff_ID = @Staff_ID ,
            Status_Type = 21
    WHERE   Data_ID = @Pre_DataID
    
    
    
    --更新Workstation_work表
    UPDATE  dbo.Basic_WorkStation_Work
    SET     WS_Status_Type = 3 ,--正在服务
            Track_No = @Track_No ,
            Queue_No = @Queue_No ,
            SrvCode_ID = @SrvCode_ID ,
            SrvGroup_ID = @SrvGroup_ID ,
            Customer_ID = @Customer_ID ,
            Customer_Name = @Customer_Name ,
            Customer_Type = @Customer_Type ,
            DataID = @DataID--当前服务客户
    WHERE   WS_ID = @WS_ID
    
    --更新选中的数据
    UPDATE  dbo.Basic_Queue_Work
    SET     Status_Type = 11 ,
            Next_Time = GETDATE() ,
            End_Time = GETDATE() ,
            Stamp_Time = GETDATE() ,
            WS_ID = @WS_ID ,
            Call_Times = 1 ,
            Staff_Code = @Staff_Code ,
            Staff_ID = @Staff_ID
    WHERE   Data_ID = @DataID

    SELECT TOP 1
            @Next_Queue_No = Queue_No ,
            @Next_Customer_Name = Customer_Name
    FROM    dbo.View_Queue
    WHERE   Status_Type = 3
            AND Priority_ID = @Priority_ID

    IF ( @Next_Customer_Name IS NULL ) 
        BEGIN
            SET @Next_Customer_Name = N'' 
        END
        
    IF ( @Next_Queue_No IS NULL ) 
        BEGIN
            SET @Next_Queue_No = 0
        END
        
        
    --******************2014-4-24 去掉候诊客户
    SET @Next_Customer_Name = N'' 
    SET @Next_Queue_No = 0
    --******************

   --插入CMD 
    EXEC SP_Cmd_WS_Call_Appoint @SrvGroup_ID, @SrvGroup_Name, @SrvGroup_Letter,
        @Queue_No, @Customer_Name, @Next_Queue_No, @Next_Customer_Name, @WS_ID,
        @WS_No, @WS_Name, @WS_Display_ID, @WS_Display_Type, @WS_Display_Name,
        @Staff_Name

    --成功
    SELECT  1

go

